#include <iostream>

using namespace std; 

void clear_screen()
{
	cout << "\033c";
}